package lt.vilnius.kaavaInc.calculator5000.main;

/**
 *
 * @author Kava
 */
public class Calculator5000
{
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        new CalculatorWindow().setVisible(true);
    }

}
