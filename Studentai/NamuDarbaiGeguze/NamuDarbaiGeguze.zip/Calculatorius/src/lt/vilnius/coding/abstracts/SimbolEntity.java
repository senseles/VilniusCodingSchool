/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lt.vilnius.coding.abstracts;

/**
 *
 * @author Daniel
 */
public class SimbolEntity {

    private int skaicius1;
    private int skaicius2;
    private String veiksmas;

    public int getSkaicius1() {
        return skaicius1;
    }

    public void setSkaicius1(int skaicius1) {
        this.skaicius1 = skaicius1;
    }

    public int getSkaicius2() {
        return skaicius2;
    }

    public void setSkaicius2(int skaicius2) {
        this.skaicius2 = skaicius2;
    }

    public String getVeiksmas() {
        return veiksmas;
    }

    public void setVeiksmas(String veiksmas) {
        this.veiksmas = veiksmas;
    }

}
