package lt.vilnius.coding.main;

import lt.vilnius.coding.gui.MainPage;

/**
 *
 * @author Adam
 */
public class Calculator {

    public static void main(String[] args) {
        new MainPage().setVisible(true);
    }

}
