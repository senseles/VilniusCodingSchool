OTF and TTF: Cronus (Regular, Italic, Bold, Bold Italic, Rounded, Rounded Italic, Rounded Bold, Rounded Bold Italic)
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net

Say hello to Cronus! A simple enough everyday font with just enough personality to take home to mom. Originally styled as a thin sans serif I stumbled onto the concept of rounded terminals by complete accident. I couldn't decide which looked better so both regular and rounded are included. 
Cronus won't do your taxes for you but would love to be the display font for your new app, powerpoint presentation, or company logo. Lowercase alternates such as a, g, and y (as well as their corresponding European accents) are included along with kerning and several different versions
to give your project just the right look. The curvy structure and clean, even line weight of Cronus is sure to compliment a bold title or provide easy legibility for descriptive text. Vertical strokes make it an ideal choice for display on smartphones and tablets. 
All 8 versions are included for $15 or purchase of a commercial license. Just use the payment link on my homepage.  

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info. I also design custom fonts for 
businesses, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 


visit www.sharkshock.net for more and take a bite out of BORING design!

tags: sans, sans serif, children, kids, book, display, font, typeface, sports, illustration, office, project, rounded, straight, geo, san, publishing, magazine, logo, company, Sharkshock, Europe, diacritics, Polish, Czech, German, French, accents, Spanish, Latin, kerning, OTF, alternates, stylistic

